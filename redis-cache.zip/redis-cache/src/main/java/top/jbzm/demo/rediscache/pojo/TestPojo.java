package top.jbzm.demo.rediscache.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * @author zhengyi
 * @date 2018/8/2 3:39 PM
 **/
@Getter
@Setter
public class TestPojo {
    private String name;
    private Integer id;
    private Long timestamp;
}